ScreenRuler Application
-----------------------

ScreenRuler Application can be used while debugging UI applications. It can measure and align any UI controls in Pixels, Inches and Centimeters. The application also displays the co-ordinates of selected control.

User can move it around the screen by simply dragging it, you can resize the ruler by pulling its edges, and you can flip it by double clicking it.

For further control over the application, use its context menu.